<?php
$cities = array("Keelung City", "New Taipei City", "Taipei City", "Taoyuan City", "Hsinchu County",
                "Hsinchu City", "Miaoli City", "Miaoli County", "Taichung City", "Changhua County",
                "Changhua City", "Nantou City", "Nantou County", "Yunlin County", "Chiayi County",
                "Chiayi City", "Tainan City", "Kaohsiung City", "Pingtung County", "Pingtung City",
                "Yilan County", "Yilan City", "Hualien County", "Hualien City", "Taitung City",
                "Taitung County", "Penghu County", "Green Island", "Orchid Island", "Kinmen County",
                "Matsu", "Lienchiang County");

$amount = array("(售完) 0", "(稀少) 1 ~ 499", "(充足) 500+");
?>